package ulearn.practice1;

public interface ICoordinateCalculator
{
    double Calculate(double[] velocity, double x0, double v0, int t);
}
