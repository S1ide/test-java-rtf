﻿public class Code
{
    //region Main
    public static void main(String[] args)
    {
        System.out.println(args);
    }
    //endregion Main
}